export type Status = 'Liberado' | 'Em uso' | 'Em manutenção';

export interface Equipment {
  id: string;
  name: string;
  muscleGroup: string;
  location: string;
  status: Status;
  maintenanceReason?: string;
  updatedAt: string;
}

export interface EquipmentFormData {
  name: string;
  muscleGroup: string;
  location: string;
  status: Status;
  maintenanceReason?: string;
}
