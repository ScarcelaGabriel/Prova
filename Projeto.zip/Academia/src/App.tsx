import { useEffect, useMemo, useState, type ReactNode, type FormEvent } from 'react';
import { Activity, AlertTriangle, ArrowDownAZ, ArrowUpAZ, BarChart3, CheckCircle2, Dumbbell, Filter, ListChecks, MapPin, Plus, Settings2, ShieldCheck, Trash2, Wrench, X } from 'lucide-react';
import { initialEquipment } from './data';
import type { Equipment, EquipmentFormData, Status } from './types';

const STORAGE_KEY = 'gymcontrol-equipment-v2';
const statuses: Status[] = ['Liberado', 'Em uso', 'Em manutenção'];
const statusClass: Record<Status, string> = { 'Liberado': 'success', 'Em uso': 'info', 'Em manutenção': 'warning' };

function generateId() {
  try {
    const c = (globalThis as any).crypto;
    if (c && typeof c.randomUUID === 'function') return c.randomUUID();
  } catch {}
  return `id_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 9)}`;
}

type SortDirection = 'asc' | 'desc';

type MetricProps = { icon: ReactNode; label: string; value: number; helper?: string };
function Metric({ icon, label, value, helper }: MetricProps) {
  return <div className="metric"><div className="metric-icon">{icon}</div><div><span>{label}</span><strong>{value}</strong>{helper && <small>{helper}</small>}</div></div>;
}

type StatusBadgeProps = { status: Status };
function StatusBadge({ status }: StatusBadgeProps) {
  return <span className={`badge ${statusClass[status]}`}><i />{status}</span>;
}

type EquipmentTableProps = {
  items: Equipment[];
  onStatusChange: (item: Equipment, status: Status) => void;
  onEdit: (item: Equipment) => void;
  onRemove: (id: string) => void;
};
function EquipmentTable({ items, onStatusChange, onEdit, onRemove }: EquipmentTableProps) {
  return <div className="table-wrap"><table><thead><tr><th>EQUIPAMENTO</th><th>GRUPO MUSCULAR</th><th>LOCALIZAÇÃO</th><th>STATUS</th><th>MOTIVO</th><th>AÇÕES</th></tr></thead><tbody>
    {items.map(item => <tr key={item.id}>
      <td><div className="equipment-name"><div className="mini-icon"><Dumbbell size={16} /></div><div><strong>{item.name}</strong><small>Atualizado {formatDate(item.updatedAt)}</small></div></div></td>
      <td>{item.muscleGroup}</td>
      <td><span className="location"><MapPin size={14} />{item.location}</span></td>
      <td><StatusBadge status={item.status} /></td>
      <td>{item.maintenanceReason || <span className="muted">—</span>}</td>
      <td><div className="row-actions">
        <select value={item.status} onChange={e => onStatusChange(item, e.target.value as Status)} aria-label={`Alterar status de ${item.name}`}>{statuses.map(s => <option key={s}>{s}</option>)}</select>
        <button className="icon-btn" onClick={() => onEdit(item)} title="Editar"><Settings2 size={16} /></button>
        <button className="icon-btn danger" onClick={() => onRemove(item.id)} title="Excluir"><Trash2 size={16} /></button>
      </div></td>
    </tr>)}
    {items.length === 0 && <tr><td colSpan={6} className="empty">Nenhum equipamento encontrado.</td></tr>}
  </tbody></table></div>;
}

function App() {
  const [items, setItems] = useState<Equipment[]>(() => {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null') || initialEquipment; } catch { return initialEquipment; }
  });
  const [filter, setFilter] = useState<'Todos' | Status>('Todos');
  const [search, setSearch] = useState('');
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc');
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Equipment | null>(null);
  const [toast, setToast] = useState('');

  useEffect(() => localStorage.setItem(STORAGE_KEY, JSON.stringify(items)), [items]);
  useEffect(() => { if (toast) { const timer = window.setTimeout(() => setToast(''), 2800); return () => window.clearTimeout(timer); } }, [toast]);

  const counts = useMemo(() => ({
    total: items.length,
    available: items.filter(i => i.status === 'Liberado').length,
    inUse: items.filter(i => i.status === 'Em uso').length,
    maintenance: items.filter(i => i.status === 'Em manutenção').length,
  }), [items]);
  const unavailable = counts.inUse + counts.maintenance;
  const availabilityRate = counts.total ? Math.round((counts.available / counts.total) * 100) : 0;
  const unavailableRate = counts.total ? Math.round((unavailable / counts.total) * 100) : 0;

  const filtered = useMemo(() => {
    const term = search.toLowerCase().trim();
    const result = items.filter(i => (filter === 'Todos' || i.status === filter) && `${i.name} ${i.muscleGroup} ${i.location}`.toLowerCase().includes(term));
    return [...result].sort((a, b) => sortDirection === 'asc' ? a.name.localeCompare(b.name, 'pt-BR') : b.name.localeCompare(a.name, 'pt-BR'));
  }, [items, filter, search, sortDirection]);

  function saveEquipment(data: EquipmentFormData) {
    const now = new Date().toISOString();
    if (editing) {
      setItems(prev => prev.map(i => i.id === editing.id ? { ...i, ...data, updatedAt: now } : i));
      setToast('Equipamento atualizado.');
    } else {
      setItems(prev => [...prev, { ...data, id: generateId(), updatedAt: now }]);
      setToast('Equipamento cadastrado.');
    }
    closeForm();
  }

  function closeForm() { setShowForm(false); setEditing(null); }
  function openNew() { setEditing(null); setShowForm(true); }
  function edit(item: Equipment) { setEditing(item); setShowForm(true); }
  function remove(id: string) { if (window.confirm('Excluir este equipamento?')) { setItems(prev => prev.filter(i => i.id !== id)); setToast('Equipamento excluído.'); } }

  function transition(item: Equipment, nextStatus: Status) {
    if (nextStatus === item.status) return;
    if (nextStatus === 'Liberado' && item.status === 'Em manutenção') {
      setEditing(item);
      setShowForm(true);
      setToast('Para liberar, conclua a manutenção pelo formulário.');
      return;
    }
    if (nextStatus === 'Em manutenção') {
      const reason = window.prompt('Informe o motivo da manutenção:')?.trim();
      if (!reason) { setToast('Alteração cancelada: o motivo é obrigatório.'); return; }
      updateStatus(item.id, nextStatus, reason);
      return;
    }
    updateStatus(item.id, nextStatus);
  }

  function updateStatus(id: string, status: Status, reason?: string) {
    setItems(prev => prev.map(i => i.id === id ? { ...i, status, maintenanceReason: status === 'Em manutenção' ? reason : undefined, updatedAt: new Date().toISOString() } : i));
    setToast(`Status alterado para “${status}”.`);
  }

  return <div className="app-shell">
    <header className="topbar"><div className="brand"><div className="brand-icon"><Dumbbell size={22} /></div><div><strong>GymControl</strong><span>Controle de equipamentos</span></div></div><div className="header-right"><span className="project-code">PP-1374ZFJ-1NXR2JR</span><div className="header-pill"><ShieldCheck size={16} /> Dados salvos no navegador</div></div></header>
    <main className="container">
      <section className="hero"><div><div className="eyebrow">PAINEL DO INSTRUTOR</div><h1>Controle de Equipamentos de Academia</h1><p>Registre, acompanhe e altere o status dos equipamentos.</p></div><button className="primary" onClick={openNew}><Plus size={18} /> Novo equipamento</button></section>
      <section className="metrics">
        <Metric icon={<ListChecks />} label="Total" value={counts.total} />
        <Metric icon={<CheckCircle2 />} label="Liberados" value={counts.available} helper={`${availabilityRate}% do total`} />
        <Metric icon={<Activity />} label="Em uso" value={counts.inUse} />
        <Metric icon={<Wrench />} label="Manutenção" value={counts.maintenance} />
      </section>
      <section className="indicator-strip"><div><BarChart3 size={18} /><span><strong>{availabilityRate}%</strong> disponibilidade</span></div><div><AlertTriangle size={18} /><span><strong>{unavailableRate}%</strong> indisponíveis</span></div></section>
      {unavailable >= 5 && <div className="threshold"><AlertTriangle size={19} /><div><strong>Alerta de capacidade — limite 5</strong><span>Há 5 ou mais equipamentos indisponíveis (em uso ou manutenção). Verifique a capacidade operacional.</span></div></div>}
      <section className="workspace">
        <div className="toolbar"><div className="search"><Filter size={17} /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar equipamento, grupo ou localização..." /></div><div className="toolbar-actions"><div className="filters">{(['Todos', ...statuses] as const).map(s => <button key={s} className={filter === s ? 'filter active' : 'filter'} onClick={() => setFilter(s)}>{s}</button>)}</div><button className="sort-btn" onClick={() => setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc')} title="Alternar ordenação">{sortDirection === 'asc' ? <ArrowDownAZ size={16} /> : <ArrowUpAZ size={16} />} {sortDirection === 'asc' ? 'A → Z' : 'Z → A'}</button></div></div>
        <EquipmentTable items={filtered} onStatusChange={transition} onEdit={edit} onRemove={remove} />
      </section>
      <section className="bottom-grid"><div className="info-card"><div className="card-title"><BarChart3 size={19} /><strong>Indicadores calculados</strong></div><p>Os indicadores abaixo são recalculados diretamente a partir da lista de equipamentos.</p><div className="progress"><span style={{ width: `${availabilityRate}%` }} /></div><div className="indicator-row"><strong>{availabilityRate}%</strong><span>equipamentos liberados</span></div><div className="indicator-row"><strong>{unavailable}</strong><span>equipamentos indisponíveis</span></div></div><div className="info-card"><div className="card-title"><Wrench size={19} /><strong>Regra de manutenção</strong></div><p>Ao entrar em manutenção, o motivo é obrigatório. Um equipamento em manutenção não pode ser liberado diretamente pelo seletor; a conclusão deve ser registrada no formulário de edição.</p></div></section>
    </main>
    <footer>GymControl · PP-1374ZFJ-1NXR2JR · Projeto individual · React + Vite + TypeScript</footer>
    {showForm && <EquipmentModal initial={editing} onClose={closeForm} onSave={saveEquipment} />}
    {toast && <div className="toast"><CheckCircle2 size={17} />{toast}</div>}
  </div>;
}

type EquipmentModalProps = { initial: Equipment | null; onClose: () => void; onSave: (data: EquipmentFormData) => void };
function EquipmentModal({ initial, onClose, onSave }: EquipmentModalProps) {
  const [name, setName] = useState(initial?.name || '');
  const [muscleGroup, setMuscleGroup] = useState(initial?.muscleGroup || '');
  const [location, setLocation] = useState(initial?.location || '');
  const [status, setStatus] = useState<Status>(initial?.status || 'Liberado');
  const [reason, setReason] = useState(initial?.maintenanceReason || '');
  const [maintenanceCompleted, setMaintenanceCompleted] = useState(false);
  const [error, setError] = useState('');
  const isFinishingMaintenance = initial?.status === 'Em manutenção' && status === 'Liberado';

  function submit(e: FormEvent) {
    e.preventDefault();
    if (!name.trim() || !muscleGroup.trim() || !location.trim()) { setError('Preencha todos os campos obrigatórios.'); return; }
    if (status === 'Em manutenção' && !reason.trim()) { setError('O motivo da manutenção é obrigatório.'); return; }
    if (isFinishingMaintenance && !maintenanceCompleted) { setError('Confirme que a manutenção foi concluída antes de liberar.'); return; }
    onSave({ name: name.trim(), muscleGroup: muscleGroup.trim(), location: location.trim(), status, maintenanceReason: status === 'Em manutenção' ? reason.trim() : undefined });
  }

  return <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><div className="modal"><div className="modal-head"><div><span className="eyebrow">CADASTRO</span><h2>{initial ? 'Editar equipamento' : 'Novo equipamento'}</h2></div><button className="close" onClick={onClose}><X /></button></div><form onSubmit={submit}>
    <label>Nome do equipamento<input value={name} onChange={e => setName(e.target.value)} placeholder="Ex.: Supino Reto" /></label>
    <div className="two"><label>Grupo muscular<input value={muscleGroup} onChange={e => setMuscleGroup(e.target.value)} placeholder="Ex.: Peito" /></label><label>Localização<input value={location} onChange={e => setLocation(e.target.value)} placeholder="Ex.: Sala de Musculação" /></label></div>
    <label>Status<select value={status} onChange={e => setStatus(e.target.value as Status)}>{statuses.map(s => <option key={s}>{s}</option>)}</select></label>
    {status === 'Em manutenção' && <label>Motivo da manutenção<textarea value={reason} onChange={e => setReason(e.target.value)} placeholder="Descreva o motivo..." rows={3} /></label>}
    {isFinishingMaintenance && <label className="checkline"><input type="checkbox" checked={maintenanceCompleted} onChange={e => setMaintenanceCompleted(e.target.checked)} /> Confirmo que a manutenção foi concluída e o equipamento pode voltar a ser liberado.</label>}
    {error && <div className="form-error"><AlertTriangle size={16} />{error}</div>}
    <div className="modal-actions"><button type="button" className="secondary" onClick={onClose}>Cancelar</button><button type="submit" className="primary">{initial ? 'Salvar alterações' : 'Cadastrar equipamento'}</button></div>
  </form></div></div>;
}

function formatDate(value: string) { return new Intl.DateTimeFormat('pt-BR', { dateStyle: 'short', timeStyle: 'short' }).format(new Date(value)); }
export default App;
