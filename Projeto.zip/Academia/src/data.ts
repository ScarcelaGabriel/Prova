import type { Equipment } from './types';

export const initialEquipment: Equipment[] = [
  { id: '1', name: 'Supino Reto', muscleGroup: 'Peito', location: 'Sala de Musculação', status: 'Liberado', updatedAt: '2026-09-17T07:30:00' },
  { id: '2', name: 'Leg Press 45°', muscleGroup: 'Pernas', location: 'Sala de Pernas', status: 'Em uso', updatedAt: '2026-09-17T07:40:00' },
  { id: '3', name: 'Puxada Alta', muscleGroup: 'Costas', location: 'Sala de Musculação', status: 'Liberado', updatedAt: '2026-09-17T07:20:00' },
  { id: '4', name: 'Cadeira Extensora', muscleGroup: 'Quadríceps', location: 'Sala de Pernas', status: 'Em manutenção', maintenanceReason: 'Cabo de aço com desgaste', updatedAt: '2026-09-17T06:55:00' },
  { id: '5', name: 'Rosca Scott', muscleGroup: 'Bíceps', location: 'Sala de Musculação', status: 'Liberado', updatedAt: '2026-09-17T07:10:00' },
  { id: '6', name: 'Remada Baixa', muscleGroup: 'Costas', location: 'Sala de Musculação', status: 'Em uso', updatedAt: '2026-09-17T07:50:00' },
];
